const { app, BrowserWindow, ipcMain } = require('electron');

/**
 * Create a new window
 */
const createWindow = () => {
  let mainWindow = new BrowserWindow({
    width: 1920, 
    // height: 540, 
    height: 432,  // 540/125 = 432 , 125% is windows display scaling
    frame: false, x: 0, y: 0,
    webPreferences: {
      /** Enable node integration */
      nodeIntegration: true,
      contextIsolation: false,
    }
  });

  /** Open devTools */
  //  mainWindow.webContents.openDevTools();

  /** Load the index.html page */
  mainWindow.loadFile('index.html');
};

/**
 * Initialize the application
 */
const init = () => {
  /** Create app window */
  createWindow();

  /** Define channel name */
  const CHANNEL_NAME = 'main';

  /**
   * Add an IPC event listener for the channel
   */
  ipcMain.on(CHANNEL_NAME, (event, data) => {
    /** Show the request data */
    console.log(data);

    /** Send a response for a synchronous request */
    var correctImageFileName = getMySetChoiceName();
 
    event.returnValue = correctImageFileName;
  })
};

// Also return Correct Answer FileName
function getMySetChoiceName() {
  var fs = require('fs');
  var dirPath = "myimages";
  var fileNames = fs.readdirSync(dirPath);

  var elementToRemove = Math.floor(Math.random() * fileNames.length); 
  var removedElements = fileNames.splice(elementToRemove,1);
  var correctAnsFileName = removedElements[0];

  elementToRemove = Math.floor(Math.random() * fileNames.length); 
  removedElements = fileNames.splice(elementToRemove,1);
  var wrongAns1FileName = removedElements[0];  

  elementToRemove = Math.floor(Math.random() * fileNames.length); 
  removedElements = fileNames.splice(elementToRemove,1);  
  var wrongAns2FileName = removedElements[0];

  var options = {encoding: 'utf16le' };
  var fileEncodingBOM = "\ufeff" ; // Proper encoding of Swedish characters

  // writeFile function with filename, content and callback function
  fs.writeFile('correctAns.txt', fileEncodingBOM + correctAnsFileName.split(".")[0], options, function (err) {
    if (err) throw err;
    console.log('File is created successfully.');
  });
  
  // writeFile function with filename, content and callback function
  fs.writeFile('wrongAns1.txt', fileEncodingBOM +wrongAns1FileName.split(".")[0], options, function (err) {
    if (err) throw err;
    console.log('File is created successfully.');
  });
  
  // writeFile function with filename, content and callback function
  fs.writeFile('wrongAns2.txt', fileEncodingBOM + wrongAns2FileName.split(".")[0], options, function (err) {
    if (err) throw err;
    console.log('File is created successfully.');
  });  

  return correctAnsFileName;
}

/**
 * Run the app
 */
app.on('ready', init);