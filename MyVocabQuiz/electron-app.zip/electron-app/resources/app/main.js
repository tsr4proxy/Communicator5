const { app, BrowserWindow, ipcMain } = require('electron');

/**
 * Create a new window
 */
const createWindow = () => {
  let mainWindow = new BrowserWindow({
    width: 1920, 
    // height: 540, 
    height: 432,  // 540/125 = 432 , 125% is windows display scaling
    frame: false, x: 0, y: 0,
    webPreferences: {
      /** Enable node integration */
      nodeIntegration: true,
      contextIsolation: false,
    }
  });

  /** Open devTools */
  //  mainWindow.webContents.openDevTools();

  /** Load the index.html page */
  mainWindow.loadFile('index.html');
};

/**
 * Initialize the application
 */
const init = () => {
  /** Create app window */
  createWindow();

  /** Define channel name */
  const CHANNEL_NAME = 'main';

  /**
   * Add an IPC event listener for the channel
   */
  ipcMain.on(CHANNEL_NAME, (event, data) => {
    /** Show the request data */
    console.log(data);

    /** Send a response for a synchronous request */
    var correctImageFileName = getMySetChoiceName();
 
    event.returnValue = correctImageFileName;
  })
};

// Also return Correct Answer FileName
function getMySetChoiceName() {
  var fs = require('fs');
  
  var selectedFileName  = "selectedDirName.txt";
  var correctAnsFileName  = "correctAns.txt";
  var wrongAns1FileName = "wrongAns1.txt";
  var wrongAns2FileName = "wrongAns2.txt";
  var dirPath           = "C:\\mydata_c5\\vocab_quiz\\";
  var selectedCategoryPath ;
  var selectedCategory;

  // Read the selectedCategory
  try {
    var options = {encoding: 'utf16le' };
    const data = fs.readFileSync(dirPath + selectedFileName, options );
    console.log("Read data-len is " , data.length ," data is ", data)
    selectedCategory = data.slice(1);
    console.log("selectedCategory data-len is " , selectedCategory.length ," selectedCategory data is ", selectedCategory);
  } catch (err) {
    console.error(err)
  }

  selectedCategoryPath = dirPath + selectedCategory + "\\" ;  
  console.log("selectedCategoryPath is " , selectedCategoryPath);


  var allImagefileNames = fs.readdirSync(selectedCategoryPath);

  var elementToRemove = Math.floor(Math.random() * allImagefileNames.length); 
  var removedElements = allImagefileNames.splice(elementToRemove,1);
  var correctAnsFileContent = removedElements[0];

  elementToRemove = Math.floor(Math.random() * allImagefileNames.length); 
  removedElements = allImagefileNames.splice(elementToRemove,1);
  var wrongAns1FileContent = removedElements[0];  

  elementToRemove = Math.floor(Math.random() * allImagefileNames.length); 
  removedElements = allImagefileNames.splice(elementToRemove,1);  
  var wrongAns2FileContent = removedElements[0];

  var options = {encoding: 'utf16le' };
  var fileEncodingBOM = "\ufeff" ; // Proper encoding of Swedish characters

  // writeFile function with filename, content and callback function
  fs.writeFile(dirPath + correctAnsFileName, fileEncodingBOM + correctAnsFileContent.split(".")[0], options, function (err) {
    if (err) throw err;
    console.log('File is created successfully.');
  });
  
  // writeFile function with filename, content and callback function
  fs.writeFile(dirPath + wrongAns1FileName, fileEncodingBOM + wrongAns1FileContent.split(".")[0], options, function (err) {
    if (err) throw err;
    console.log('File is created successfully.');
  });
  
  // writeFile function with filename, content and callback function
  fs.writeFile(dirPath + wrongAns2FileName, fileEncodingBOM + wrongAns2FileContent.split(".")[0], options, function (err) {
    if (err) throw err;
    console.log('File is created successfully.');
  });  

  console.log('selectedCategoryPath + correctAnsFileContent ', selectedCategoryPath + correctAnsFileContent);
  return selectedCategoryPath + correctAnsFileContent;
}

/**
 * Run the app
 */
app.on('ready', init);